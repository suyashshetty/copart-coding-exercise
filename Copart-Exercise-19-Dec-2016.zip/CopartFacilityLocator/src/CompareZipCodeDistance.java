import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CompareZipCodeDistance {

	private long sourceZip;

	private List<CopartFacility> cpFacility;

	public CompareZipCodeDistance(long sourceZipCode, List<CopartFacility> facilities) {
		cpFacility = facilities;
		sourceZip = sourceZipCode;
	}

	public CopartFacility getNearestFacility() {

		int index = -1;
		int smallDistIndex = 0;
		double distance = 0.0;

		for (CopartFacility cp : cpFacility) {
			index++;
			try {

				URL url = new URL(
						"https://www.zipcodeapi.com/rest/SH8Be5Im18StbtqknXgm9a9aoJZsukum2CXhHGDJOvd0ZDknBAJKLSV9CVC6g6si/distance.json"
								+ "/" + sourceZip + "/" + cp.getZipCode() + "/km");

				HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

				conn.setRequestMethod("GET");
				double dist = sourceZip - cp.getZipCode();
				if (dist < 0)
					dist = -1 * dist;
				if (dist < 10000)
					if (conn.getResponseCode() == 200) {

						BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

						StringBuilder sb = new StringBuilder();
						String output;
						while ((output = br.readLine()) != null) {

							sb.append(output);
						}

						try {
							JSONParser parser = new JSONParser();
							Object obj = parser.parse(sb.toString());
							JSONObject jb = (JSONObject) obj;

							double distSep = (double) jb.get("distance");
							
							if (distSep < distance || distance == 0) {
								distance = distSep;
								smallDistIndex = index;
							}

						} catch (Exception e) {
							// e.printStackTrace();
						}

						conn.disconnect();
					}
			} catch (IOException e) {

				e.printStackTrace();
			}

		}

		System.out.println("Smallest distance :" + distance);
		return cpFacility.get(smallDistIndex);

	}

}
