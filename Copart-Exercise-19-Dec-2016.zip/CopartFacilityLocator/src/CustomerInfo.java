
public class CustomerInfo {

	private long zipCode;
	private String custId;

	public CustomerInfo(String customerId, long custZipCode) {

		custId = customerId;
		zipCode = custZipCode;
	}

	public long getZipCode() {
		return zipCode;
	}

	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

}
