import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CopartFacility {

	private String facilityId;
	private String City;
	private String State;
	private long zipCode;

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facility) {
		this.facilityId = facility;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public long getZipCode() {
		return zipCode;
	}

	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}

}
