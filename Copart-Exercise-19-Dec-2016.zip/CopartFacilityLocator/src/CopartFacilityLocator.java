import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CopartFacilityLocator {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the file locations containing copart facilities :");
		String fileLoc = input.nextLine();

		System.out.println("Enter the customer id :");
		String custId = input.nextLine();

		System.out.println("Enter the customer zipcode :");
		long custZipCode = input.nextLong();
		input.nextLine();
		CustomerInfo cInfo = new CustomerInfo(custId, custZipCode);

		List<CopartFacility> copartFacility = new ArrayList<CopartFacility>();

		// Read from the file
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		try {

			br = new BufferedReader(new FileReader(fileLoc));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] facility = line.split(cvsSplitBy);

				CopartFacility cp = new CopartFacility();
				cp.setFacilityId(facility[0].toString().replace("\"", ""));
				cp.setCity(facility[1].toString().replace("\"", ""));
				cp.setState(facility[2].toString().replace("\"", ""));
				cp.setZipCode(Long.parseLong(facility[3].replace("\"", "")));

				copartFacility.add(cp);

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		CompareZipCodeDistance czd = new CompareZipCodeDistance(cInfo.getZipCode(), copartFacility);
		CopartFacility cf = czd.getNearestFacility();

		System.out.println("For Customer " + cInfo.getCustId() + " with a provided zipcode of " + cInfo.getZipCode()
				+ ", closest copart facility is " + cf.getCity() + ", " + cf.getState());

	}
}
