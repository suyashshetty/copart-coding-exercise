import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;

public class ZipCodeLookUp {

	private long zipCode;
	private String city;
	private String state;

	public long getZipCode() {
		return zipCode;
	}

	public String getZipCodeString() {
		return Long.toString(zipCode);
	}

	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	private void parseGoogleOutput(String response) {
		/*
		 * JSONParser parser = new JSONParser(); String response =
		 * "{interests : [{interestKey:Dogs}, {interestKey:Cats}]}";
		 * 
		 * JSONObject jsonObj = (JSONObject) parser.parse(response);
		 */
	}

	public void computeLocation() {

		try {

			URL url = new URL(
					"http://maps.googleapis.com/maps/api/geocode/json?address=" + getZipCodeString() + "&sensor=true");

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setRequestMethod("GET");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {

				sb.append(output);
			}

			JSONObject jsonObject = new JSONObject();
			try {
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(sb.toString());
				JSONObject jb = (JSONObject) obj;

				// now read
				JSONArray jsonObjectResults = (JSONArray) jb.get("results");
				JSONObject jsonObjectAddress = (JSONObject) jsonObjectResults.get(0);
				JSONArray jsonAddr = (JSONArray) jsonObjectAddress.get("address_components");
				for (int x = 0; x < jsonAddr.size(); x++) {
					JSONObject jo = (JSONObject) jsonAddr.get(x);
					JSONArray types = (JSONArray) jo.get("types");

					// Get the city
					if (types.get(0).toString().equals("locality"))
						setCity(jo.get("short_name").toString());

					// Get the state
					if (types.get(0).toString().equals("administrative_area_level_1"))
						setState(jo.get("short_name").toString());

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			conn.disconnect();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
