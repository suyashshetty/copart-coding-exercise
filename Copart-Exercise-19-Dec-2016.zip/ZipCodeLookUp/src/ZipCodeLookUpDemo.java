import java.util.Scanner;

public class ZipCodeLookUpDemo {

	public static void main(String[] args) {

		ZipCodeLookUp zip = new ZipCodeLookUp();

		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a zip code : ");
		String zipCode = scan.nextLine();
		
		try {
			zip.setZipCode(Long.parseLong(zipCode));
			zip.computeLocation();
			System.out.println(zip.getCity() + ", " + zip.getState());
		} catch (NumberFormatException ex) {
			System.out.println("Not a valid zip code");

		} catch (IndexOutOfBoundsException ex) {
			System.out.println("Not a valid zip code");
		}

	}

}
