import java.util.Scanner;

public class DNASequencing {

	
	
	

	public static String getLongestSubstring(String input) {
		
		
		return null;
	}

}
