import java.util.Scanner;

public class DNASequenceDemo {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a DNA Sequence:");
		String input = scan.nextLine();

		DNASequence seq = new DNASequence(input);

		if (seq.validateDNA()) {
			seq.computeLongestSequence();
			System.out.println(seq.getLongestSequence() + " " + seq.getLongestSequenceLength());
		} else {
			System.out.println("Not a valid DNA string");
		}

	}

}
