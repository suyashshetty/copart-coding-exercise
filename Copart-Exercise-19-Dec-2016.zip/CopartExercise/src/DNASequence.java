/**
 * 
 */

/**
 * @author suyash
 *
 */
public class DNASequence {

	private String dnaString;
	private char longestSequence;
	private int longestSequenceLength;

	private final char adenine = 'A';
	private final char thymine = 'T';
	private final char guanine = 'G';
	private final char cytosine = 'C';

	public DNASequence(String input) {
		setDnaString(input);
	}

	public boolean validateDNA() {

		char[] dnaChars = getDnaString().toCharArray();
		for (char ch : dnaChars) {

			if (ch == adenine || ch == thymine || ch == guanine || ch == cytosine)
				continue;
			else
				return false;
		}

		return true;
	}

	public String getDnaString() {
		return dnaString;
	}

	public void setDnaString(String dnaString) {
		this.dnaString = dnaString;
	}

	public void computeLongestSequence() {
		char[] dnaChar = dnaString.toCharArray();
		char initChar = ' ';
		int initCount = 0;
		for (int iter = 0; iter < dnaString.length(); iter++) {

			if (iter == 0) {
				initChar = dnaChar[iter];
				initCount = 1;
				setLongestSequence(initChar);
				setLongestSequenceLength(1);
			} else {
				if (dnaChar[iter] == initChar) {
					initCount++;

				} else {

					switch (initChar) {
					case 'A':
						if (initCount > getLongestSequenceLength()) {
							setLongestSequence(adenine);
							setLongestSequenceLength(initCount);
						}
						break;
					case 'G':
						if (initCount > getLongestSequenceLength()) {
							setLongestSequence(guanine);
							setLongestSequenceLength(initCount);
						}
						break;
					case 'T':
						if (initCount > getLongestSequenceLength()) {
							setLongestSequence(thymine);
							setLongestSequenceLength(initCount);
						}
						break;
					case 'C':
						if (initCount > getLongestSequenceLength()) {
							setLongestSequence(cytosine);
							setLongestSequenceLength(initCount);
						}
						break;

					}
					initChar = dnaChar[iter];
					initCount = 1;
				}

				// for the terminating string
				switch (initChar) {
				case 'A':
					if (initCount > getLongestSequenceLength()) {
						setLongestSequence(adenine);
						setLongestSequenceLength(initCount);
					}
					break;
				case 'G':
					if (initCount > getLongestSequenceLength()) {
						setLongestSequence(guanine);
						setLongestSequenceLength(initCount);
					}
					break;
				case 'T':
					if (initCount > getLongestSequenceLength()) {
						setLongestSequence(thymine);
						setLongestSequenceLength(initCount);
					}
					break;
				case 'C':
					if (initCount > getLongestSequenceLength()) {
						setLongestSequence(cytosine);
						setLongestSequenceLength(initCount);
					}
					break;

				}
			}

		}

	}

	public int getLongestSequenceLength() {
		return longestSequenceLength;
	}

	public void setLongestSequenceLength(int longestSequenceLength) {
		this.longestSequenceLength = longestSequenceLength;
	}

	public char getLongestSequence() {
		return longestSequence;
	}

	public void setLongestSequence(char longestSequence) {
		this.longestSequence = longestSequence;
	}

}
