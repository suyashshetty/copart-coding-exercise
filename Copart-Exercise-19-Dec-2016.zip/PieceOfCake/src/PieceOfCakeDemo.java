import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class PieceOfCakeDemo {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		try {

			Scanner input = new Scanner(System.in);
			System.out.println("Enter choice of input: \n1.File \n2.Console :");
			int choice = input.nextInt();
			input.nextLine();
			switch (choice) {
			case 1:
				System.out.print("Enter the file path with extension : ");

				File file = new File(input.nextLine());

				input = new Scanner(file);
				int rowNum = 0;
				int count = 0;
				while (input.hasNextLine()) {
					if (rowNum == 0)
						count = input.nextInt();
					System.out.println("Number of cakes : " + count);
					if (count > 0 && count < 101) {
						for (int i = 0; i < count; i++) {
							long areaCakes = input.nextLong();
							PieceOfCake pc;
							if (areaCakes < 500000001) {
								pc = new PieceOfCake(areaCakes);
								System.out.println(pc.getPerimeter());
							} else {
								System.out.println("Invalid area at the input..!!");
							}

						}
					} else {
						System.out.println("Invalid number of cakes..!!");
					}
				}
				input.close();

				break;
			case 2:
				System.out.print("Enter the number of cakes (<= 100): ");
				input = new Scanner(System.in);

				int numCakes = input.nextInt();

				if (numCakes > 0 && numCakes < 101) {
					System.out.print("Enter the area of " + numCakes + " cakes separated by newline: \n");

					long[] areaCakes = new long[numCakes];
					PieceOfCake[] pcCakes = new PieceOfCake[numCakes];
					for (int x = 0; x < numCakes; x++) {

						areaCakes[x] = input.nextLong();
						if (areaCakes[x] < 500000001)
							pcCakes[x] = new PieceOfCake(areaCakes[x]);
					}

					for (int x = 0; x < numCakes; x++) {

						if (pcCakes[x].getPerimeter() > 0)
							System.out.println(pcCakes[x].getPerimeter());
						else
							System.out.println("Invalid area at the input..!!");
					}
				} else {
					System.out.println("Invalid number of cakes..!!");
				}

				break;
			default:
				System.out.println("Invalid input..!!");
				break;

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		/*
		 * PieceOfCake pc = new PieceOfCake(1);
		 * 
		 * pc = new PieceOfCake(121); System.out.println(pc.getPerimeter()); pc
		 * = new PieceOfCake(96); System.out.println(pc.getPerimeter()); pc =
		 * new PieceOfCake(35); System.out.println(pc.getPerimeter());
		 */

	}

}
