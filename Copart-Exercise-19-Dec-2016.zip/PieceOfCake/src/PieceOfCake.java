
public class PieceOfCake {

	private long perimeter;
	private long area;
	private long length;
	private long breadth;

	public PieceOfCake(long areaOfCake) {
		area = areaOfCake;
		perimeter = 0;
		computeDimensions();
	}

	public void computeDimensions() {
		if (area != 0) {
			long median = (long) Math.sqrt(area);

			while (area % median != 0)
				--median;

			length = area / median;

			breadth = area / length;
			perimeter = 2 * length + 2 * breadth;

		}
	}

	public long getPerimeter() {
		return perimeter;
	}

	public void setPerimeter(long perimeter) {
		this.perimeter = perimeter;
	}

	public long getArea() {
		return area;
	}

	public void setArea(long area) {
		this.area = area;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public long getBreadth() {
		return breadth;
	}

	public void setBreadth(long breadth) {
		this.breadth = breadth;
	}

}
